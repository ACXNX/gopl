<!-- 链接文件，用于被其它md文件包含 -->

<!-- 人名 -->
[AlanDonovan]:      https://github.com/adonovan
[BrianKernighan]:   http://www.cs.princeton.edu/~bwk/
[DennisRitchie]:    http://genius.cat-v.org/dennis-ritchie/
[RobertGriesemer]:  http://research.google.com/pubs/author96.html
[RobPike]:          http://genius.cat-v.org/rob-pike/",
[KenThompson]:      http://genius.cat-v.org/ken-thompson/
[RussCox]:          http://research.swtch.com/
[NiklausWirth]:     https://en.wikipedia.org/wiki/Niklaus_Wirth
[TonyHoare]:        https://en.wikipedia.org/wiki/Tony_Hoare
[FredBrooks]:       http://www.cs.unc.edu/~brooks/

<!-- 图书 -->
[gopl]:                     http://gopl.io
[tcpl]:                     http://s3-us-west-2.amazonaws.com/belllabs-microsite-dritchie/cbook/index.html
[TheCProgrammingLanguage]:  http://s3-us-west-2.amazonaws.com/belllabs-microsite-dritchie/cbook/index.html
[ThePracticeOfProgramming]: https://en.wikipedia.org/wiki/The_Practice_of_Programming

<!-- Go语言 -->
[Golang]:                 https://golang.org/
[Golang-oracle]:          https://godoc.org/golang.org/x/tools/oracle
[Golang-godoc-analysis]:  https://godoc.org/golang.org/x/tools/cmd/godoc
[Golang-gorename]:        https://godoc.org/golang.org/x/tools/cmd/gorename

<!-- 其他语言 -->
[Alef]:      http://doc.cat-v.org/plan_9/2nd_edition/papers/alef/
[APL]:       https://en.wikipedia.org/wiki/APL_(programming_language)
[Limbo]:     http://doc.cat-v.org/inferno/4th_edition/limbo_language/
[Modula-2]:  https://en.wikipedia.org/wiki/Modula-2
[Newsqueak]: http://doc.cat-v.org/bell_labs/squeak/
[Oberon]:    https://en.wikipedia.org/wiki/Oberon_(programming_language)
[Oberon-2]:  https://en.wikipedia.org/wiki/Oberon-2_(programming_language)
[Pascal]:    https://en.wikipedia.org/wiki/Pascal_(programming_language)
[Scheme]:    https://en.wikipedia.org/wiki/Scheme_(programming_language)
[Squeak]:    http://doc.cat-v.org/bell_labs/squeak/

<!-- 系统 -->
[UNIX]:     http://doc.cat-v.org/unix/
[Linux]:    http://www.linux.org/
[FreeBSD]:  https://www.freebsd.org/
[OpenBSD]:  http://www.openbsd.org/
[MacOSX]:   http://www.apple.com/cn/osx/
[Plan9]:    http://plan9.bell-labs.com/plan9/
[Windows]:  https://www.microsoft.com/zh-cn/windows/

<!-- 其他 -->
[BellLabs]: http://www.cs.bell-labs.com/
[CSP]:      https://en.wikipedia.org/wiki/Communicating_sequential_processes
[KR]:       https://en.wikipedia.org/wiki/K%26R
